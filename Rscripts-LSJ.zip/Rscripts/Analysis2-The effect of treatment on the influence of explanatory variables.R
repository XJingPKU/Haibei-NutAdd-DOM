# Analysis 2: The effect of treatment on the influence of explanatory variables
# # R code-summary
# Jing xin  and Liu Shengjuan 
# 2025/04/05
# This script analyzes the impact of processing effects on the influence of 
# explanatory variables using a linear mixed-effects model.(Fig.3)

###########################################################
rm(list = ls())

# load library
library(tidyverse)
library(nlme)
library(readr)
library(dplyr)
library(cowplot)
library(ggprism)
library(ggplot2)
library(openxlsx)
library(lmerTest)
library(lme4)           
library(dplyr)          
library(cowplot)        
library(patchwork)    
library(RColorBrewer)
library(purrr)
library(tidyr)

sessionInfo()

char2seed("DOM")

# load data

dom <- read_csv("D:/Jing Lab/Todesk/NutNet_carbon/data/data_processing/summary_data_2025.4.4.csv")

###########################################################
# clean data
# clean data
dom_NP_treat <- dom %>% 
  filter(treat %in% c("CK", "N", "P", "NP"),
         depth %in% c("0-10","20-30")) %>%
  mutate(
    fb = factor(block),
    fp = factor(plot),
    fd = factor(depth, levels = c("0-10", "20-30")),
    treat = factor(treat, levels = c("CK", "N", "P", "NP")),
    linN = ifelse(treat %in% c("N", "NP"), 1, 0),
    linP = ifelse(treat %in% c("P", "NP"), 1, 0))

dom_NP <- dom_NP_treat %>% 
  pivot_longer(cols = BGB:E4_E5,
               names_to = "variable",
               values_to = "value") %>% 
  mutate(variable = factor(variable)) %>%
  filter(variable %in% c("SOC","DOC","SOC_STN","HIX","BIX","FI","SR","suv254","E4_E5")) %>%
  group_by(variable) %>%
  mutate(value_std = scale(value)) %>%
  ungroup()

plyr::dlply(dom_NP, "variable", function(x) {
  fit_lme <- lme(value_std ~ linN * linP * fd, 
                 random = ~1|fb/fp,
                 data = x)
  car::Anova(fit_lme, type = 3)
})

# Table S3  analyzing treatment effects
dom_NP_1 <- dom_NP_treat %>% 
  pivot_longer(cols = BGB:E4_E5,
               names_to = "variable",
               values_to = "value") %>% 
  mutate(variable = factor(variable)) %>%
  filter(variable %in% c("BGB","blroot","bdroot","CBH","BG","PPO","PER","pH","EC","SWC"))


plyr::dlply(dom_NP_1, "variable", function(x) {
  fit_lme <- lme(value ~ linN * linP*fd  ,random = ~1|fb/fp,
                 data =x)
  car::Anova(fit_lme,type=3)
  #summary(fit_lme)
})

# Table S4  analyzing treatment effects
dom_NP_2 <- dom_NP_treat %>% 
  pivot_longer(cols = BGB:E4_E5,
               names_to = "variable",
               values_to = "value") %>% 
  mutate(variable = factor(variable)) %>%
  filter(variable %in% c("AGB","alplant","litter"))


plyr::dlply(dom_NP_2, "variable", function(x) {
  fit_lme <- lme(value ~ linN * linP  ,random = ~1|fb/fp,
                 data =x)
  car::Anova(fit_lme,type=3)
  #summary(fit_lme)
})


# 修正后的 Table S3 整理代码
table_s3_results <- dom_NP_1 %>%
  group_by(variable) %>%
  group_modify(~ {
    fit_lme <- lme(value ~ linN * linP * fd, random = ~1|fb/fp, data = .x)
    anova_result <- car::Anova(fit_lme, type = 3)
    
    result_df <- as.data.frame(anova_result) %>%
      rownames_to_column("term") %>%
      mutate(Chisq = round(Chisq, 3),
             P_value = round(P_value, 4)) %>%
      select(term, Chisq, Df, P_value)
    
    return(result_df)
  }) %>%
  ungroup()

# 修正后的 Table S4 整理代码
table_s4_results <- dom_NP_2 %>%
  group_by(variable) %>%
  group_modify(~ {
    fit_lme <- lme(value ~ linN * linP, random = ~1|fb/fp, data = .x)
    anova_result <- car::Anova(fit_lme, type = 3)
    
    result_df <- as.data.frame(anova_result) %>%
      rownames_to_column("term") %>%
      mutate(Chisq = round(Chisq, 3),
             P_value = round(P_value, 4)) %>%
      select(term, Chisq, Df, P_value)
    
    return(result_df)
  }) %>%
  ungroup()

# 保存结果
write.csv(table_s3_results, "Table_S3_treatment_effects.csv", row.names = FALSE)
write.csv(table_s4_results, "Table_S4_treatment_effects.csv", row.names = FALSE)

# 定义要绘制的变量列表
target_variables <- c("alplant", "litter", "BGB","blroot",  "CBH", "BG", "PPO", "PER", "pH", "EC", "SWC")

# 对alplant和litter变量只保留0-10cm的数据，其他变量保留所有土层
plot_data <- dom_NP_treat %>%
  filter(variable %in% target_variables) %>%
  # 对alplant和litter只保留0-10cm，其他变量保留所有土层
  filter(!(variable %in% c("alplant", "litter") & fd != "0-10")) %>%
  group_by(treat, fd, variable) %>%
  summarise(
    mean_value = mean(value, na.rm = TRUE),
    sd_value = sd(value, na.rm = TRUE),
    n = n(),
    se = sd_value/sqrt(n),
    .groups = 'drop')

# 定义变量顺序（按照目标变量列表的顺序）
variable_order <- target_variables

# 定义处理组颜色
treat_colors <- c("CK" = "lightblue",  
                  "N" = "#fcbba1",   
                  "P" = "#fb6a4a",   
                  "NP" = "#a50f15")  

# 准备绘图数据
final_data <- plot_data %>%
  mutate(
    treat = factor(treat, levels = c("CK", "N", "P", "NP")),  
    variable = factor(variable, levels = variable_order))
# 绘制柱状图
Fig_target <- ggplot() +
  geom_col(
    data = final_data,
    aes(x = fd, y = mean_value, fill = treat),
    position = position_dodge(width = 0.8),
    width = 0.7,
    color = NA,  # 去掉柱子边框颜色
    alpha = 0.8) +
  geom_errorbar(
    data = final_data,
    aes(
      x = fd,
      ymin = mean_value - se,
      ymax = mean_value + se,
      group = treat),
    position = position_dodge(width = 0.8),
    width = 0.2,
    size = 0.6,
    color = "gray30") +
  geom_vline(
    xintercept = 1.5,  
    linetype = "dashed",
    color = "gray",
    size = 0.6) +
  scale_fill_manual(values = treat_colors, name = "Treatment") +
  facet_wrap(
    ~ variable,
    scales = "free_y",  # 每个变量使用独立的y轴尺度
    ncol = 4,           # 每行4个变量
    strip.position = "left",
    labeller = labeller(variable = label_value)) +
  labs(x = "Soil Depth (cm)", y = NULL) +
  theme_bw(base_size = 12) +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    strip.background = element_blank(),
    strip.placement = "outside",
    strip.text.y = element_text(size = 11, face = "bold", color = "gray30"),
    axis.text.x = element_text(angle = 0, hjust = 0.5, color = "gray30"),
    axis.text.y = element_text(color = "gray30"),
    legend.position = "top",
    legend.title = element_text(color = "gray30"),
    legend.text = element_text(color = "gray30"),
    panel.spacing = unit(0.5, "lines"),
    panel.border = element_rect(color = "black", linewidth = 0.8)) +  # 边框颜色改为黑色
  scale_y_continuous(
    expand = expansion(mult = c(0.05, 0.15))) +  # 增加上方空间，从0.10增加到0.15
  theme(
    strip.text.y.left = element_text(angle = 90)) +
  scale_x_discrete(labels = c("0-10" = "0-10 cm", "10-20" = "10-20 cm", "20-30" = "20-30 cm"))

# 输出结果
print(Fig_target)
# Save figure 
ggsave("./outputs/Fig.3.pdf",
       width = 180, height = 165, units = "mm")


###########################################################
#                    End of Script                        #
###########################################################