# Analysis 1: The impact of processing efficiency on DOM quantity and quality
# # R code-summary
# Jing xin  and Liu Shengjuan 
# 2025/04/05
# This script analyzes the impact of processing effects on the quantity and 
# quality of DOM using a linear mixed-effects model.(Fig.1 and Fig.2)

###########################################################
rm(list = ls())

# load library
library(tidyverse)
library(nlme)
library(emmeans)
library(TeachingDemos)
library(readr)
library(dplyr)
library(cowplot)
library(ggprism)
library(ggplot2)
library(openxlsx)
library(varpart)
library(ggExtra) 
library(lmerTest)
library(agricolae)
library(lmerTest)       
library(ggplot2)        
library(lme4)           
library(dplyr)          
library(cowplot)        
library(patchwork)    
library(FactoMineR)
library(factoextra)
library(RColorBrewer)
library(purrr)
library(tidyr)

sessionInfo()

char2seed("DOM")

# load data

dom <- read_csv("D:/Jing Lab/Todesk/NutNet_carbon/data/data_processing/summary_data_2025.4.4.csv")

###########################################################
# clean data
dom_NP_treat <- dom %>% 
  filter(treat %in% c("CK", "N", "P", "NP"),
         depth %in% c("0-10","20-30")) %>%
  mutate(
    fb = factor(block),
    fp = factor(plot),
    fd = factor(depth, levels = c("0-10", "20-30")),
    treat = factor(treat, levels = c("CK", "N", "P", "NP")),
    linN = ifelse(treat %in% c("N", "NP"), 1, 0),
    linP = ifelse(treat %in% c("P", "NP"), 1, 0))


###########################################################
# Table S1 Linear mixed-effects models summarizing the effects of nutrient addition

dom_NP <- dom_NP_treat %>% 
  pivot_longer(cols = BGB:E4_E5,
               names_to = "variable",
               values_to = "value") %>% 
  mutate(variable = factor(variable)) %>%
  filter(variable %in% c("SOC","DOC","SOC_STN","HIX","BIX","FI","SR","suv254","E4_E5"))



plyr::dlply(dom_NP, "variable", function(x) {
  fit_lme <- lme(value ~ linN * linP*fd  ,random = ~1|fb/fp,
                 data =x)
  # car::Anova(fit_lme,type=3)
  summary(fit_lme)
})

# Table S3  analyzing treatment effects
dom_NP_1 <- dom_NP_treat %>% 
  pivot_longer(cols = BGB:E4_E5,
               names_to = "variable",
               values_to = "value") %>% 
  mutate(variable = factor(variable)) %>%
  filter(variable %in% c("BGB","blroot","bdroot","CBH","BG","PPO","PER","pH","EC","SWC"))


plyr::dlply(dom_NP_1, "variable", function(x) {
  fit_lme <- lme(value ~ linN * linP*fd  ,random = ~1|fb/fp,
                 data =x)
  car::Anova(fit_lme,type=3)
  #summary(fit_lme)
})

# Table S4  analyzing treatment effects
dom_NP_2 <- dom_NP_treat %>% 
  pivot_longer(cols = BGB:E4_E5,
               names_to = "variable",
               values_to = "value") %>% 
  mutate(variable = factor(variable)) %>%
  filter(variable %in% c("AGB","alplant","litter"))


plyr::dlply(dom_NP_2, "variable", function(x) {
  fit_lme <- lme(value ~ linN * linP  ,random = ~1|fb/fp,
                 data =x)
  car::Anova(fit_lme,type=3)
  #summary(fit_lme)
})

# Calculate the mean and standard deviation

plot_data <- dom_NP %>%
  group_by(treat, fd, variable) %>%
  summarise(
    mean_value = mean(value, na.rm = TRUE),
    sd_value = sd(value, na.rm = TRUE),
    n = n(),
    se = sd_value/sqrt(n),
    .groups = 'drop')

variable_order <- c("SOC","DOC","SOC_STN","HIX","BIX","FI","SR","suv254","E4_E5")

treat_colors <- c("CK" = "lightblue",  
                  "N" = "#fcbba1",   
                  "P" = "#fb6a4a",   
                  "NP" = "#a50f15")  

final_data <- plot_data %>%
  mutate(
    treat = factor(treat, levels = c("CK", "N", "P", "NP")),  
    variable = factor(variable, levels = variable_order))


# Plotting a bar chart

Fig_1 <- ggplot() +
  geom_col(
    data = final_data,
    aes(x = fd, y = mean_value, fill = treat),
    position = position_dodge(width = 0.8),
    width = 0.7,
    color = NA,  
    size = 0.5,
    alpha = 0.8) +
  geom_errorbar(
    data = final_data,
    aes(
      x = fd,
      ymin = mean_value - se,
      ymax = mean_value + se,
      group = treat),
    position = position_dodge(width = 0.8),
    width = 0.2,
    size = 0.6,
    color = "gray30") +
  geom_vline(
    xintercept = 1.5,  
    linetype = "dashed",
    color = "gray",
    size = 0.6) +
  scale_fill_manual(values = treat_colors, name = "Treatment") +
  facet_wrap(
    ~ variable,
    scales = "free_y",
    ncol = 3,
    strip.position = "left",
    labeller = labeller(variable = label_value)) +
  labs(x = "Soil Depth (cm)", y = NULL) +
  theme_bw(base_size = 12) +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    strip.background = element_blank(),
    strip.placement = "outside",
    strip.text.y = element_text(size = 11, face = "bold", color = "black"),  
    axis.text.x = element_text(angle = 0, hjust = 0.5, color = "black"),    
    axis.text.y = element_text(color = "black"),                          
    axis.title = element_text(color = "black"),                             
    legend.position = "top",
    legend.title = element_text(color = "black"),                       
    legend.text = element_text(color = "black"),                            
    panel.spacing = unit(0.5, "lines"),
    panel.border = element_rect(color = "black", linewidth = 0.8)) +        
  scale_y_continuous(expand = expansion(mult = c(0.05, 0.10))) +
  theme(
    strip.text.y.left = element_text(angle = 90)) +
  scale_x_discrete(labels = c("0-10" = "0-10 cm", "20-30" = "20-30 cm"))

# Output results

print(Fig_1)

# Save figure 
ggsave("./outputs/Fig.1.pdf",
       width = 180, height = 165, units = "mm")

# Fig.2 linear mixed-effects model
# Add a standardization step during the data preprocessing phase. 
dom_NP_scaled <- dom_NP %>%
  group_by(variable) %>%  
  mutate(value_scaled = as.numeric(scale(value))) %>%  
  ungroup()

# Modify the model analysis section to use standardized data. 
model_results_scaled <- plyr::dlply(dom_NP_scaled, "variable", function(x) {
  fit_lme <- lme(value_scaled ~ linN * linP *fd,  # Using the standardized dependent variable
                 random = ~1|fb/fp,
                 data = x)
  return(list(
    anova = anova(fit_lme),
    summary = summary(fit_lme)
  ))
})

# Extract the fixed-effects results from the standardized model 
fixed_effects_scaled <- map2_dfr(model_results_scaled, names(model_results_scaled), ~{
  sum <- .x$summary
  data.frame(
    Variable = .y,
    Term = rownames(sum$tTable),
    Estimate = sum$tTable[, "Value"],
    SE = sum$tTable[, "Std.Error"],
    DF = sum$tTable[, "DF"],  # Newly added degree-of-freedom column
    t_value = sum$tTable[, "t-value"],  # Added t-value column
    p_value = 2 * pt(abs(sum$tTable[, "t-value"]), 
                     sum$tTable[, "DF"], lower.tail = FALSE),  # Calculate the two-tailed p-value
    CI_low_95 = sum$tTable[, "Value"] - 1.96*sum$tTable[, "Std.Error"],
    CI_high_95 = sum$tTable[, "Value"] + 1.96*sum$tTable[, "Std.Error"],
    CI_low_80 = sum$tTable[, "Value"] - 1.28*sum$tTable[, "Std.Error"],
    CI_high_80 = sum$tTable[, "Value"] + 1.28*sum$tTable[, "Std.Error"]
  )
})

# Create a Distinctiveness Tag Column and Color Column
fixed_effects_scaled <- fixed_effects_scaled %>%
  mutate(
    significance = case_when(
      p_value < 0.001 ~ "***",
      p_value < 0.01  ~ "**",
      p_value < 0.05  ~ "*",
      TRUE            ~ ""
    ),
    # 添加颜色分类列
    point_color = case_when(
      p_value < 0.05 & Estimate > 0 ~ "black",     # 显著正效应 - 红色
      p_value < 0.05 & Estimate < 0 ~ "red",    # 显著负效应 - 蓝色
      TRUE ~ "grey50"                            # 不显著 - 灰色
    )
  )

#Create a naming reference table for Y-axis labels 
term_labels <- c(
  "linN" = "N",
  "linP" = "P",
  "fd10-20" = "10-20cm",
  "fd20-30" = "20-30cm",
  "linN:linP" = "N*P",
  "linN:fd10-20" = "N*10-20cm",
  "linN:fd20-30" = "N*20-30cm",
  "linP:fd10-20" = "P*10-20cm",
  "linP:fd20-30" = "P*20-30cm",
  "linN:linP:fd10-20" = "N*P*10-20cm",
  "linN:linP:fd20-30" = "N*P*20-30cm")

# Drawing Section 
fixed_effects_scaled %>%
  filter(Term != "(Intercept)") %>%
  mutate(
    Term = factor(Term, levels = term_order),
    Variable = factor(Variable, levels = variable_order)
  ) %>%
  ggplot(aes(x = Estimate, y = Term)) +
  geom_vline(xintercept = 0, linetype = "dashed", color = "grey50") +
  # Plot confidence intervals
  geom_linerange(aes(xmin = CI_low_95, xmax = CI_high_95),
                 size = 0.8, color = "grey", alpha = 0.7) +
  geom_linerange(aes(xmin = CI_low_80, xmax = CI_high_80),
                 size = 1.2, color = "black") +
  # 修改点颜色：根据point_color列设置颜色
  geom_point(aes(color = point_color), size = 2) +
  # 手动设置颜色标度
  scale_color_manual(values = c("black" = "black", "red" = "red", "grey50" = "grey50"),
                     guide = "none") +  # 不显示图例
  # Add salience annotations
  geom_text(aes(label = significance, x = CI_high_95 * 1.2),  
            size = 3.5, color = "grey20", fontface = "bold") +
  facet_wrap(~Variable, ncol = 3) +
  labs(x = "Standardized effect estimate", 
       y = "",
       caption = "") +  
  theme_bw() +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major = element_blank(),
    axis.text.x = element_text(angle = 0, hjust = 0.5),
    strip.background = element_rect(fill = "white"),
    plot.caption = element_text(hjust = 0)) +
  scale_y_discrete(
    limits = rev,
    labels = term_labels)

# Save figure 
ggsave("./outputs/Fig.2.pdf",
       width = 180, height = 165, units = "mm")


###########################################################
#                    End of Script                        #
###########################################################