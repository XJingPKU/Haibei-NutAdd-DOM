# Analysis 3: analysis of mechanisms affecting DOM quantity and quality
# # R code-summary 
# Jing xin  and Liu Shengjuan 
# 2025/04/05
# This script analyzes the impact of  mechanisms affecting DOM quantity and 
# quality using a linear mixed-effects model.(Fig.4)

###########################################################
rm(list = ls())

# load library
library(tidyverse)
library(nlme)
library(readr)
library(dplyr)
library(cowplot)
library(ggprism)
library(ggplot2)
library(openxlsx)
library(lmerTest)
library(lme4)           
library(dplyr)          
library(cowplot)        
library(patchwork)    
library(RColorBrewer)
library(purrr)
library(tidyr)

sessionInfo()

char2seed("DOM")

# load data

dom <- read_csv("D:/Jing Lab/Todesk/NutNet_carbon/data/data_processing/summary_data_2025.4.4.csv")

###########################################################
# clean data
dom_NP_treat <- dom %>% 
  filter(treat %in% c("CK", "N", "P", "NP"),
         depth %in% c("0-10","20-30")) %>%
  mutate(
    fb = factor(block),
    fp = factor(plot),
    fd = factor(depth, levels = c("0-10", "20-30")),
    treat = factor(treat, levels = c("CK", "N", "P", "NP")),
    linN = ifelse(treat %in% c("N", "NP"), 1, 0),
    linP = ifelse(treat %in% c("P", "NP"), 1, 0))

# Define a normalization function using scale
standardize_variables <- function(data, exclude_vars = NULL) {
  vars_to_standardize <- names(data)[sapply(data, is.numeric)] 
  if (!is.null(exclude_vars)) {
    vars_to_standardize <- setdiff(vars_to_standardize, exclude_vars)
  }
  
  data[vars_to_standardize] <- lapply(data[vars_to_standardize], function(x) {
    as.vector(scale(x, center = TRUE, scale = TRUE))
  })
  
  return(data)
}

custom_order <- c("pH", "EC", "SWC", "PPO", "PER", "BG", "CBH", 
                  "BGB", "blroot", "litter", "alplant")


# Plot forest maps for all response variables (9-variable faceted)
response_vars <- c("SOC", "DOC", "SOC/STN", "HIX", "BIX", "FI", "SR", "suv254", "E4_E5")


plot_forest_all_depths <- function() {
  
  all_results <- map_dfr(response_vars, function(response_var) {
    lmedata <- dom %>% 
      filter(treat %in% c("CK", "N", "P", "NP"),
             depth %in% c("0-10", "20-30")) %>% 
      mutate(fb = factor(block),
             fp = factor(plot),
             fd = factor(depth),
             linN = ifelse(treat %in% c("N", "NP"), 1, 0),
             linP = ifelse(treat %in% c("P", "NP"), 1, 0),
             linN_linP = linN * linP)
    
    depth_results <- map_dfr(c("0-10", "20-30"), function(depth_value) {
      depth_data <- lmedata %>% filter(depth == depth_value)
      
      exclude_vars <- c("block", "plot", "depth", "treat")
      depth_data_std <- standardize_variables(depth_data, exclude_vars = exclude_vars)
      
 
      formula_str <- paste(response_var, "~ alplant + litter + BGB+ blroot+",
                           "BG + CBH + PPO + PER + pH + EC + SWC")
      
  
      lme_model <- lme(
        fixed = as.formula(formula_str),
        random = ~1 | fb/fp, 
        data = depth_data_std,
        method = "REML"  
      )
      
     
      P <- summary(lme_model)
      fixed_effects <- as.data.frame(P$tTable) %>%
        rownames_to_column("Variable") %>%
        rename(Estimate = Value, 
               StdError = `Std.Error`,
               Pvalue = `p-value`) %>%
        mutate(
          Lower = Estimate - 1.96 * StdError,
          Upper = Estimate + 1.96 * StdError,
          Significance = case_when(
            Pvalue < 0.001 ~ "***",
            Pvalue < 0.01 ~ "**",
            Pvalue < 0.05 ~ "*",
            Pvalue < 0.1 ~ ".",
            TRUE ~ " "
          ),
          Depth = depth_value,
          Response = response_var  # 添加响应变量标识
        ) %>%
        filter(Variable != "(Intercept)")
      
      return(fixed_effects)
    })
    
    return(depth_results)
  })
  

  all_results <- all_results %>%
    mutate(
      Group = case_when(
        Variable %in% c("alplant", "litter", "BGB","blroot") ~ "Plant",
        Variable %in% c("pH", "EC", "SWC") ~ "pHEC",
        Variable %in% c("BG", "CBH") ~ "hydro_enzy",
        Variable %in% c("PPO", "PER") ~ "oxid_enzy",
        TRUE ~ "Other"
      ),
      Variable = factor(Variable, levels = custom_order),

      Response = factor(Response, levels = response_vars)
    ) %>%
    arrange(Variable) %>%
    drop_na(Estimate)
  
 
  all_results <- all_results %>%
    mutate(
      Variable_idx = as.numeric(Variable),
      y_position = ifelse(Depth == "0-10", Variable_idx + 0.2, Variable_idx - 0.2)
    )
  

  p <- ggplot(all_results, aes(x = Estimate, y = y_position, shape = Depth)) +
  
    geom_vline(xintercept = 0, linetype = "dashed", color = "gray50") +
    
    geom_errorbarh(
      aes(xmin = Lower, xmax = Upper),  
      height = 0,  
      size = 0.8,  
      alpha = 0.8,
      color = "black"  ) +
    
    
    geom_point(aes(color = ifelse(Pvalue < 0.05, 
                                  ifelse(Estimate > 0, "Positive", "Negative"), 
                                  "Non-significant")), 
               size = 2) +  
    
    
    geom_text(
      aes(x = ifelse(Estimate > 0, Upper + 0.3, Lower - 0.3), 
          label = Significance),
      size = 4, color = "black", show.legend = FALSE) +
    
    scale_x_continuous(limits = c(-2, 2), breaks = seq(-2, 2, by = 1)) +
    scale_y_continuous(
      breaks = 1:length(custom_order),
      labels = custom_order) +
    
    scale_color_manual(
      name = "Significance",
      values = c("Positive" = "black", "Negative" = "red", "Non-significant" = "grey50"),  # 修改：不显著的点用灰色
      breaks = c("Positive", "Negative", "Non-significant"),
      labels = c("Significant positive", "Significant negative", "Non-significant")
    ) +
    scale_shape_manual(values = c(16, 17)) + 
    facet_wrap(~Response, ncol = 3, scales = "free") +
    
    labs(x = "Standardized coefficient estimate", y = "") +
    theme_bw() +
    theme(
      panel.grid.minor = element_blank(),
      panel.grid.major = element_blank(),
      axis.text = element_text(size = 10, color = "black"),
      axis.text.x = element_text(size = 10),
      axis.text.y = element_text(
        size = 10, 
        color = "black",
        hjust = 1,
        face = "bold"
      ),
      axis.title.x = element_text(size = 12, face = "bold"),
      strip.background = element_rect(fill = "grey90", color = "black", linewidth = 0.5),
      strip.text = element_text(size = 12, face = "bold"),
      legend.position = "none",  
      panel.spacing = unit(1, "lines")
    )
  
  g <- ggplotGrob(p)
  return(g)
}


combined_plot <- plot_forest_all_depths()
grid::grid.draw(combined_plot)

# Save figure 
ggsave("./outputs/Fig.4.pdf",
       width = 180, height = 165, units = "mm")




###########################################################
#                    End of Script                        #
###########################################################